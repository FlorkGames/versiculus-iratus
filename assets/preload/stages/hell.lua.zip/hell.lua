function onCreate()
	makeLuaSprite('bgintro', 'bgintro', -700, -450);
	addLuaSprite('bgintro', false);

  makeLuaSprite('INFERNO_SKY', 'INFERNO_SKY', -1500, -1500);
	addLuaSprite('INFERNO_SKY', false);
        scaleObject('INFERNO_SKY', 2, 2);
   setProperty('INFERNO_SKY.visible', false)
	
	makeLuaSprite('ROCK_BG', 'ROCK_BG', -700, 450);
	addLuaSprite('ROCK_BG', false);
	setProperty('ROCK_BG.visible', false)
end